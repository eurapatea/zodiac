﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Runtime.InteropServices;


namespace Goroskope
{
    
    public partial class Form1 : Form
    {


        public Form1()
        {
            InitializeComponent();
            labelTodayIs.Visible = true;
            labelDateToday.Visible = true;
            labelDateBirth.Visible = true;
            labelZodiac.Visible = true;
            labelChineseZodiac.Visible = true;
            labelElement.Visible = true;
            labelSeason.Visible = true;
            dateBirth.Visible = true;
            buttonAnalysis.Visible = true;
            textBoxCharacteristic.Visible = true;
            this.textBoxCharacteristic.ForeColor = System.Drawing.Color.DarkViolet;
            pictureBoxImageZodiac.Visible = true;
            pictureBoxImageChineseZodiac.Visible = true;
            pictureBoxImageElement.Visible = true;
            pictureBoxImageSeason.Visible = true;


            timerUpdate.Interval = 1000;
            timerUpdate.Enabled = true;


        }
        public int interval = 0;
        public string exePath = AppDomain.CurrentDomain.BaseDirectory;
        public string age;
        public string tobirth;
        public int vivodddr;
        public int vivodmdr;
        public int ddrnow;
        public int mdrnow;
        public int toddr;
        public int tomdr;
        
        public void dateBirth_ValueChanged(object sender, EventArgs e)
        {
            DateTime birthday = dateBirth.Value.Date;
            DateTime now = DateTime.Now;

            int agey = now.Year - birthday.Year;
            int agem = now.Month - birthday.Month;
            int aged = now.Day - birthday.Day;

            int tobirthm = now.Month - birthday.Month;
            int tobirthd = now.Day - birthday.Day;
            if (now.Month < birthday.Month || now.Month == birthday.Month && now.Day < birthday.Day)
            {
                agey--;
                agem--;
                aged--;
            }
            if (agem < 0)
            {
                agem = 12 + agem;

            }
            if (aged < 0)
            {
                aged = 32 + aged;
            }



            vivodddr = birthday.Day;
            vivodmdr = birthday.Month;
            ddrnow = now.Day;
            mdrnow = now.Month;
            tomdr = tobirthm;
            toddr = tobirthd;
            if(vivodddr >= ddrnow )
            {
                
                toddr = toddr * (-1);
            }
            if (vivodmdr >= mdrnow)
            {
                tomdr = tomdr * (-1);
                
            }

            tobirth = $"{tomdr} месяца {toddr} дней ";
            age = $"{agey} лет {agem} месяцев {aged} дней ";
            textBoxCharacteristic.Clear();
           
        }

        public void buttonAnalysis_Click(object sender, EventArgs e)
        {
            textBoxCharacteristic.Text = "Ваш возраст:";
            textBoxCharacteristic.Text += "\r\n" + age;
            if (mdrnow - vivodmdr >= 0 && ddrnow - vivodddr >= 0)
            {
                textBoxCharacteristic.Text += "\r\n" + "День рождение был ";
                textBoxCharacteristic.Text += "\r\n" + tobirth + "назад";
                textBoxCharacteristic.Text += "\r\n" + "";
            }
            else
            {
                textBoxCharacteristic.Text += "\r\n" + "До дня рождения осталось:";
                textBoxCharacteristic.Text += "\r\n" + tobirth;
                textBoxCharacteristic.Text += "\r\n" + "";
            }

            //zodiac
            int zodiacmonth = dateBirth.Value.Month;
            int zodiacday = dateBirth.Value.Day;
            
            zodiak zodiak = new zodiak();
            textBoxCharacteristic.Text += zodiak.zodiaktext(zodiacday, zodiacmonth) + "\r\n";
            pictureBoxImageZodiac.BackgroundImage = zodiak.zodiakimage(zodiacday, zodiacmonth);

            //givotnoe
            int givotnoe = dateBirth.Value.Year;
            animals animal = new animals();
            pictureBoxImageChineseZodiac.BackgroundImage = animal.animalimage(givotnoe);
            textBoxCharacteristic.Text += animal.animaltext(givotnoe) + "\r\n";
            
            //elements
            int element = dateBirth.Value.Year;
           
            element elemennt1 = new element();
            pictureBoxImageElement.BackgroundImage = elemennt1.elementImage(element);
            textBoxCharacteristic.Text += elemennt1.elementText(element) + "\r\n";


            //seasons
            int seasons = dateBirth.Value.Month;
           
            seasons season = new seasons();
            pictureBoxImageSeason.BackgroundImage = season.seasonsImage(seasons);
            textBoxCharacteristic.Text += season.seasonsText(seasons);

        }

        private void timerUpdate_Tick(object sender, EventArgs e)
        {
            labelDateToday.Text = DateTime.Now.ToShortDateString() + ": " + DateTime.Now.ToLongTimeString();
        }

        private void textBoxCharacteristic_TextChanged(object sender, EventArgs e)
        {

        }

        private void pictureBoxImageZodiac_Click(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}    


