﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;


namespace Goroskope
{
    internal class zodiak
    {

        //zodiaci
        //month
        public static int nahmonthvodolei = 01;
        public static int konmonthvodolei = 02;
        public static int nahmonthoven = 03;
        public static int konmonthoven = 04;
        public static int nahmonthrak = 06;
        public static int konmonthrak = 07;
        public static int nahmonthscorpion = 10;
        public static int konmonthscorpion = 11;
        public static int nahmonthblizneci = 05;
        public static int konmonthblizneci = 06;
        public static int nahmonthlev = 07;
        public static int konmonthlev = 08;
        public static int nahmonthvesi = 09;
        public static int konmonthvesi = 10;
        public static int nahmonthribi = 02;
        public static int konmonthribi = 03;
        public static int nahmonthstrelec = 11;
        public static int konmonthstrelec = 12;
        public static int nahmonthkozerog = 12;
        public static int konmonthkozerog = 01;
        public static int nahmonthtelec = 04;
        public static int konmonthtelec = 05;
        public static int nahmonthdeva = 08;
        public static int konmonthdeva = 09;
        //day
        public static int nahdayvodolei = 21;
        public static int kondayvodolei = 19;
        public static int nahdayoven = 21;
        public static int kondayoven = 20;
        public static int nahdayrak = 21;
        public static int kondayrak = 22;
        public static int nahdayscorpion = 23;
        public static int kondayscorpion = 22;
        public static int nahdayblizneci = 21;
        public static int kondayblizneci = 21;
        public static int nahdaylev = 23;
        public static int kondaylev = 22;
        public static int nahdayvesi = 22;
        public static int kondayvesi = 22;
        public static int nahdayribi = 20;
        public static int kondayribi = 20;
        public static int nahdaystrelec = 23;
        public static int kondaystrelec = 21;
        public static int nahdaykozerog = 22;
        public static int kondaykozerog = 20;
        public static int nahdaytelec = 21;
        public static int kondaytelec = 20;
        public static int nahdaydeva = 23;
        public static int kondaydeva = 21;
        //string Text = "\r\n" + "Характеристика по зз:";
        public string zodiaktext(int zodiacday,int zodiacmonth)   
        {

            string Text = "\r\n" + "Характеристика по зз:";
            
            if (zodiacday >= nahdayoven && zodiacmonth == nahmonthoven || zodiacday <= kondayoven && zodiacmonth == konmonthoven)
            {
                Text = Text.Insert(23,"\r\n" + "Овен. Представители этого знака целеустремленные и обычно знают, чего хотят.  Однако из-за чрезмерного напора им не всегда получается все получить. Овны — страстные, темпераментные, честные и мужественные люди, благодаря чему все, что их окружает, наполнено драйвом и энергией.");
            }

            if (zodiacday >= nahdaytelec && zodiacmonth == nahmonthtelec || zodiacday <= kondaytelec && zodiacmonth == konmonthtelec)
            {
                Text = Text.Insert(23,"\r\n" + "Телец одновременно скромен и романтичен благодаря Венере — планете любви. Тельцы, как правило, надежные, сильные, терпеливые и ответственные люди. Но иногда они могут проявлять упрямство, равнодушие и ревность. Телец — прекрасный знак, который умеет заранее планировать и ставить задачи для достижения общей цели, а также грамотно распоряжаться деньгами и просто относиться к жизни.");
            }

            if (zodiacday >= nahdayblizneci && zodiacmonth == nahmonthblizneci || zodiacday <= kondayblizneci && zodiacmonth == konmonthblizneci)
            {
                Text = Text.Insert(23,"\r\n" + "ВБлизнецы сообразительный и умный знак, для которого важно постоянно чему-то учиться и с кем-то общаться. Они умеют сопереживать и сочувствовать. Однако из-за переизбытка энергии становятся беспокойными и неспособны принимать решения и фокусироваться на чем-то одном долгое время.");
            }

            if (zodiacday >= nahdayrak && zodiacmonth == nahmonthrak || zodiacday <= kondayrak && zodiacmonth == konmonthrak)
            {
                Text = Text.Insert(23,"\r\n" + "Раки как известно, олицетворяют материнство и хранителей домашнего очага.Из лучших качеств в Раках можно выделить творческий подход и чуткость, из худших — привычку манипулировать кем-то и быть пессимистами. Хотя представители этого водяного знака домоседы по природе, но никогда не откажутся от увлекательного путешествия.");
            }

            if (zodiacday >= nahdaylev && zodiacmonth == nahmonthlev || zodiacday <= kondaylev && zodiacmonth == konmonthlev)
            {
                Text = Text.Insert(23,"\r\n" + "Львы действительно ведут себя в жизни как короли или королевы <<джунглей>>. Этот знак может быть настоящим лидером — творческим и активным, но ему также присуще временами драматизировать, стесняться, проявлять эгоизм и высокомерие. Эксперт по астрологии рекомендует <<найти баланс>> между этими качествами. Все-таки Львы как никто знают, как <<следовать зову сердца>> и не бояться этого.");
            }

            if (zodiacday >= nahdaydeva && zodiacmonth == nahmonthdeva || zodiacday <= kondaydeva && zodiacmonth == konmonthdeva)
            {
                Text = Text.Insert(23,"\r\n" + "Девы известны своей внимательностью к деталям, логичностью и прагматичностью. Этот знак глубоко предан, добр и великодушен к людям. Однако у Дев есть и отрицательные стороны. Представители этого знака любят критиковать себя и других, а также переживать по пустякам и работать больше, чем положено, забывая об отдыхе и развлечениях.");
            }

            if (zodiacday >= nahdayvesi && zodiacmonth == nahmonthvesi || zodiacday <= kondayvesi && zodiacmonth == konmonthvesi)
            {
                Text = Text.Insert(23,"\r\n" + "Весы ориентированы на партнерство. Этот знак уважает личное пространство другого человека и умеет слушать. Знает, что и когда сказать, а когда лучше промолчать. Представители этого знака, как правило, очень добрые, дипломатичные, заботливые и щедрые люди, которые стараются поступать только правильно. Но и они же склонны хранить обиду и не брать на себя ответственность, даже если стали участником какого-то конфликта.");
            }

            if (zodiacday >= nahdayscorpion && zodiacmonth == nahmonthscorpion || zodiacday <= kondayscorpion && zodiacmonth == konmonthscorpion)
            {
                Text = Text.Insert(23,"\r\n" + "Скорпион яркий и проницательный знак зодиака. Однако, несмотря на эту энергию, они часто производят впечатление замкнутых людей. Спокойствие и непринужденность — вот та атмосфера, которую любят создавать вокруг себя представители этого знака, независимо от того, что чувствуют на самом деле.");
            }

            if (zodiacday >= nahdaystrelec && zodiacmonth == nahmonthstrelec || zodiacday <= kondaystrelec && zodiacmonth == konmonthstrelec)
            {
                Text = Text.Insert(23,"\r\n" + "Стрельцы не любят подчиняться, из-за чего они часто находятся на своей волне. В астрологии представители этого знака считаются веселыми и харизматичными авантюристами со своей философией, суть которой состоит в том, чтобы сделать эту жизнь немного лучше.Но даже несмотря на это, со временем к Стрельцам приходят более глубокие знания и мудрость.");
            }

            if (zodiacday >= nahdaykozerog && zodiacmonth == nahmonthkozerog || zodiacday <= kondaykozerog && zodiacmonth == konmonthkozerog)
            {
                Text = Text.Insert(23,"\r\n" + "Козерога нельзя назвать веселым и легким знаком зодиака. Но это и к лучшему, потому что у него есть выигрышные стороны, которых нет у других. Представители этого знака сильные и стойкие люди, которые любят добиваться целей.Известные своей ответственностью, дисциплиной и чувством такта, Козероги, как правило, делают успешную карьеру. Но в семье и любви с ними могут быть проблемы из-за чрезмерной требовательности Козерогов — они возлагают слишком большие надежды на окружающих.");
            }

            if (zodiacday >= nahdayvodolei && zodiacmonth == nahmonthvodolei || zodiacday <= kondayvodolei && zodiacmonth == konmonthvodolei)
            {
                
                Text = Text.Insert(23,"\r\n" + "Водолеи знают не только, как поймать ритм жизни, но и как создать его. Представители этого знака — бунтари, которые как никто умеют находить решения старых проблем и проникать в суть того, что действительно важно, не прислушиваясь к мнению других. Однако временами они могут казаться бессердечными и непреклонными. Им тяжело выражать чувства.");
            }

            if (zodiacday >= nahdayribi && zodiacmonth == nahmonthribi || zodiacday <= kondayribi && zodiacmonth == konmonthribi)
            {
                
                Text = Text.Insert(23,"\r\n" + "Рыбы. На первый взгляд этот знак может показаться излишне романтичным и мечтательным, однако Рыбы могут также быстро остыть, если их обидеть или проявилось неуважение. Представленные двумя рыбами, плывущими в противоположных направлениях, кажется, что этот знак всегда должен делать выбор или выбирать между тем или иным путем — иногда реальностью и миром их фантазий. Рыбы — мудрые, щедрые, у них развита интуиция, но из-за чрезмерной доверчивости, часто бывают напуганы и чем-то обеспокоены.");
            }
            
            
            return Text;
        }
        public Bitmap zodiakimage(int zodiacday, int zodiacmonth)
        {

            Bitmap BackgroundImage = Properties.Resources.aries;
            if (zodiacday >= nahdayoven && zodiacmonth == nahmonthoven || zodiacday <= kondayoven && zodiacmonth == konmonthoven)
            {
                BackgroundImage = Properties.Resources.aries;

            }

            if (zodiacday >= nahdaytelec && zodiacmonth == nahmonthtelec || zodiacday <= kondaytelec && zodiacmonth == konmonthtelec)
            {
                BackgroundImage = Properties.Resources.taurus;

            }

            if (zodiacday >= nahdayblizneci && zodiacmonth == nahmonthblizneci || zodiacday <= kondayblizneci && zodiacmonth == konmonthblizneci)
            {
                BackgroundImage = Properties.Resources.gemini;

            }

            if (zodiacday >= nahdayrak && zodiacmonth == nahmonthrak || zodiacday <= kondayrak && zodiacmonth == konmonthrak)
            {
                BackgroundImage = Properties.Resources.cancer;
            }

            if (zodiacday >= nahdaylev && zodiacmonth == nahmonthlev || zodiacday <= kondaylev && zodiacmonth == konmonthlev)
            {
                BackgroundImage = Properties.Resources.leo;
            }

            if (zodiacday >= nahdaydeva && zodiacmonth == nahmonthdeva || zodiacday <= kondaydeva && zodiacmonth == konmonthdeva)
            {
                BackgroundImage = Properties.Resources.virgo;
            }

            if (zodiacday >= nahdayvesi && zodiacmonth == nahmonthvesi || zodiacday <= kondayvesi && zodiacmonth == konmonthvesi)
            {
                BackgroundImage = Properties.Resources.libra;
            }

            if (zodiacday >= nahdayscorpion && zodiacmonth == nahmonthscorpion || zodiacday <= kondayscorpion && zodiacmonth == konmonthscorpion)
            {
                BackgroundImage = Properties.Resources.scorpio;
            }

            if (zodiacday >= nahdaystrelec && zodiacmonth == nahmonthstrelec || zodiacday <= kondaystrelec && zodiacmonth == konmonthstrelec)
            {
                BackgroundImage = Properties.Resources.sagittarius;
            }

            if (zodiacday >= nahdaykozerog && zodiacmonth == nahmonthkozerog || zodiacday <= kondaykozerog && zodiacmonth == konmonthkozerog)
            {
                BackgroundImage = Properties.Resources.capricorn;
            }

            if (zodiacday >= nahdayvodolei && zodiacmonth == nahmonthvodolei || zodiacday <= kondayvodolei && zodiacmonth == konmonthvodolei)
            {
                BackgroundImage = Properties.Resources.aquarius;
            }

            if (zodiacday >= nahdayribi && zodiacmonth == nahmonthribi || zodiacday <= kondayribi && zodiacmonth == konmonthribi)
            {
                BackgroundImage = Properties.Resources.pisces;
            }


            return BackgroundImage;
        }

    }
}
