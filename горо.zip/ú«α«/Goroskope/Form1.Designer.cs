﻿
namespace Goroskope
{
    partial class Form1
    {
        /// <summary>
        /// Обязательная переменная конструктора.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Освободить все используемые ресурсы.
        /// </summary>
        /// <param name="disposing">истинно, если управляемый ресурс должен быть удален; иначе ложно.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Код, автоматически созданный конструктором форм Windows

        /// <summary>
        /// Требуемый метод для поддержки конструктора — не изменяйте 
        /// содержимое этого метода с помощью редактора кода.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.dateBirth = new System.Windows.Forms.DateTimePicker();
            this.textBoxCharacteristic = new System.Windows.Forms.TextBox();
            this.buttonAnalysis = new System.Windows.Forms.Button();
            this.labelDateBirth = new System.Windows.Forms.Label();
            this.labelTodayIs = new System.Windows.Forms.Label();
            this.pictureBoxImageZodiac = new System.Windows.Forms.PictureBox();
            this.timerUpdate = new System.Windows.Forms.Timer(this.components);
            this.labelDateToday = new System.Windows.Forms.Label();
            this.labelZodiac = new System.Windows.Forms.Label();
            this.pictureBoxImageChineseZodiac = new System.Windows.Forms.PictureBox();
            this.pictureBoxImageElement = new System.Windows.Forms.PictureBox();
            this.pictureBoxImageSeason = new System.Windows.Forms.PictureBox();
            this.labelChineseZodiac = new System.Windows.Forms.Label();
            this.labelElement = new System.Windows.Forms.Label();
            this.labelSeason = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxImageZodiac)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxImageChineseZodiac)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxImageElement)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxImageSeason)).BeginInit();
            this.SuspendLayout();
            // 
            // dateBirth
            // 
            this.dateBirth.CalendarFont = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dateBirth.CalendarForeColor = System.Drawing.Color.Aqua;
            this.dateBirth.CalendarMonthBackground = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(255)))));
            this.dateBirth.CalendarTitleBackColor = System.Drawing.Color.Green;
            this.dateBirth.CalendarTitleForeColor = System.Drawing.Color.Blue;
            this.dateBirth.CalendarTrailingForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.dateBirth.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F);
            this.dateBirth.Format = System.Windows.Forms.DateTimePickerFormat.Short;
            this.dateBirth.Location = new System.Drawing.Point(1037, 6);
            this.dateBirth.Margin = new System.Windows.Forms.Padding(4);
            this.dateBirth.MaxDate = new System.DateTime(2023, 12, 31, 0, 0, 0, 0);
            this.dateBirth.MinDate = new System.DateTime(1900, 1, 1, 0, 0, 0, 0);
            this.dateBirth.Name = "dateBirth";
            this.dateBirth.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.dateBirth.Size = new System.Drawing.Size(176, 26);
            this.dateBirth.TabIndex = 1;
            this.dateBirth.ValueChanged += new System.EventHandler(this.dateBirth_ValueChanged);
            // 
            // textBoxCharacteristic
            // 
            this.textBoxCharacteristic.BackColor = System.Drawing.Color.PaleTurquoise;
            this.textBoxCharacteristic.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.textBoxCharacteristic.Enabled = false;
            this.textBoxCharacteristic.Font = new System.Drawing.Font("Microsoft Sans Serif", 10.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(204)));
            this.textBoxCharacteristic.ForeColor = System.Drawing.Color.SeaShell;
            this.textBoxCharacteristic.Location = new System.Drawing.Point(12, 50);
            this.textBoxCharacteristic.Margin = new System.Windows.Forms.Padding(4);
            this.textBoxCharacteristic.Multiline = true;
            this.textBoxCharacteristic.Name = "textBoxCharacteristic";
            this.textBoxCharacteristic.Size = new System.Drawing.Size(799, 695);
            this.textBoxCharacteristic.TabIndex = 5;
            this.textBoxCharacteristic.TextChanged += new System.EventHandler(this.textBoxCharacteristic_TextChanged);
            // 
            // buttonAnalysis
            // 
            this.buttonAnalysis.BackColor = System.Drawing.Color.MediumAquamarine;
            this.buttonAnalysis.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.buttonAnalysis.FlatAppearance.BorderColor = System.Drawing.Color.DarkCyan;
            this.buttonAnalysis.FlatAppearance.BorderSize = 3;
            this.buttonAnalysis.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Teal;
            this.buttonAnalysis.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Aquamarine;
            this.buttonAnalysis.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonAnalysis.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.buttonAnalysis.ForeColor = System.Drawing.Color.SeaShell;
            this.buttonAnalysis.Image = ((System.Drawing.Image)(resources.GetObject("buttonAnalysis.Image")));
            this.buttonAnalysis.ImageAlign = System.Drawing.ContentAlignment.TopRight;
            this.buttonAnalysis.Location = new System.Drawing.Point(1037, 39);
            this.buttonAnalysis.Margin = new System.Windows.Forms.Padding(4);
            this.buttonAnalysis.Name = "buttonAnalysis";
            this.buttonAnalysis.Size = new System.Drawing.Size(176, 77);
            this.buttonAnalysis.TabIndex = 3;
            this.buttonAnalysis.Text = "Анализ";
            this.buttonAnalysis.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.buttonAnalysis.UseVisualStyleBackColor = false;
            this.buttonAnalysis.Click += new System.EventHandler(this.buttonAnalysis_Click);
            // 
            // labelDateBirth
            // 
            this.labelDateBirth.AutoSize = true;
            this.labelDateBirth.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDateBirth.ForeColor = System.Drawing.Color.SeaShell;
            this.labelDateBirth.Location = new System.Drawing.Point(702, 8);
            this.labelDateBirth.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelDateBirth.Name = "labelDateBirth";
            this.labelDateBirth.Size = new System.Drawing.Size(286, 26);
            this.labelDateBirth.TabIndex = 4;
            this.labelDateBirth.Text = "Укажите дату рождения:";
            // 
            // labelTodayIs
            // 
            this.labelTodayIs.AutoSize = true;
            this.labelTodayIs.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelTodayIs.ForeColor = System.Drawing.Color.SeaShell;
            this.labelTodayIs.Location = new System.Drawing.Point(7, 8);
            this.labelTodayIs.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelTodayIs.Name = "labelTodayIs";
            this.labelTodayIs.Size = new System.Drawing.Size(172, 26);
            this.labelTodayIs.TabIndex = 0;
            this.labelTodayIs.Text = "Текущая дата:";
            // 
            // pictureBoxImageZodiac
            // 
            this.pictureBoxImageZodiac.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBoxImageZodiac.Location = new System.Drawing.Point(824, 198);
            this.pictureBoxImageZodiac.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBoxImageZodiac.Name = "pictureBoxImageZodiac";
            this.pictureBoxImageZodiac.Size = new System.Drawing.Size(150, 150);
            this.pictureBoxImageZodiac.TabIndex = 6;
            this.pictureBoxImageZodiac.TabStop = false;
            this.pictureBoxImageZodiac.Click += new System.EventHandler(this.pictureBoxImageZodiac_Click);
            // 
            // timerUpdate
            // 
            this.timerUpdate.Tick += new System.EventHandler(this.timerUpdate_Tick);
            // 
            // labelDateToday
            // 
            this.labelDateToday.AutoSize = true;
            this.labelDateToday.Font = new System.Drawing.Font("Microsoft Sans Serif", 16.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelDateToday.ForeColor = System.Drawing.Color.DarkOrchid;
            this.labelDateToday.Location = new System.Drawing.Point(173, 8);
            this.labelDateToday.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelDateToday.Name = "labelDateToday";
            this.labelDateToday.Size = new System.Drawing.Size(0, 26);
            this.labelDateToday.TabIndex = 9;
            // 
            // labelZodiac
            // 
            this.labelZodiac.AutoSize = true;
            this.labelZodiac.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelZodiac.ForeColor = System.Drawing.Color.SeaShell;
            this.labelZodiac.Location = new System.Drawing.Point(820, 175);
            this.labelZodiac.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelZodiac.Name = "labelZodiac";
            this.labelZodiac.Size = new System.Drawing.Size(149, 17);
            this.labelZodiac.TabIndex = 10;
            this.labelZodiac.Text = "Ваш знак зодиака:";
            // 
            // pictureBoxImageChineseZodiac
            // 
            this.pictureBoxImageChineseZodiac.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBoxImageChineseZodiac.Location = new System.Drawing.Point(1048, 198);
            this.pictureBoxImageChineseZodiac.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBoxImageChineseZodiac.Name = "pictureBoxImageChineseZodiac";
            this.pictureBoxImageChineseZodiac.Size = new System.Drawing.Size(150, 150);
            this.pictureBoxImageChineseZodiac.TabIndex = 11;
            this.pictureBoxImageChineseZodiac.TabStop = false;
            // 
            // pictureBoxImageElement
            // 
            this.pictureBoxImageElement.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBoxImageElement.Location = new System.Drawing.Point(824, 402);
            this.pictureBoxImageElement.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBoxImageElement.Name = "pictureBoxImageElement";
            this.pictureBoxImageElement.Size = new System.Drawing.Size(150, 150);
            this.pictureBoxImageElement.TabIndex = 12;
            this.pictureBoxImageElement.TabStop = false;
            // 
            // pictureBoxImageSeason
            // 
            this.pictureBoxImageSeason.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBoxImageSeason.Location = new System.Drawing.Point(1048, 402);
            this.pictureBoxImageSeason.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBoxImageSeason.Name = "pictureBoxImageSeason";
            this.pictureBoxImageSeason.Size = new System.Drawing.Size(150, 150);
            this.pictureBoxImageSeason.TabIndex = 13;
            this.pictureBoxImageSeason.TabStop = false;
            // 
            // labelChineseZodiac
            // 
            this.labelChineseZodiac.AutoSize = true;
            this.labelChineseZodiac.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelChineseZodiac.ForeColor = System.Drawing.Color.SeaShell;
            this.labelChineseZodiac.Location = new System.Drawing.Point(1010, 175);
            this.labelChineseZodiac.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelChineseZodiac.Name = "labelChineseZodiac";
            this.labelChineseZodiac.Size = new System.Drawing.Size(231, 17);
            this.labelChineseZodiac.TabIndex = 14;
            this.labelChineseZodiac.Text = "Ваш китайский знак зодиака:";
            // 
            // labelElement
            // 
            this.labelElement.AutoSize = true;
            this.labelElement.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelElement.ForeColor = System.Drawing.Color.SeaShell;
            this.labelElement.Location = new System.Drawing.Point(820, 379);
            this.labelElement.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelElement.Name = "labelElement";
            this.labelElement.Size = new System.Drawing.Size(108, 17);
            this.labelElement.TabIndex = 15;
            this.labelElement.Text = "Ваша стихия:";
            // 
            // labelSeason
            // 
            this.labelSeason.AutoSize = true;
            this.labelSeason.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelSeason.ForeColor = System.Drawing.Color.SeaShell;
            this.labelSeason.Location = new System.Drawing.Point(1044, 379);
            this.labelSeason.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.labelSeason.Name = "labelSeason";
            this.labelSeason.Size = new System.Drawing.Size(170, 17);
            this.labelSeason.TabIndex = 16;
            this.labelSeason.Text = "Ваш сезон рождения:";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.DarkSlateGray;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.ClientSize = new System.Drawing.Size(1223, 758);
            this.Controls.Add(this.labelSeason);
            this.Controls.Add(this.labelElement);
            this.Controls.Add(this.labelChineseZodiac);
            this.Controls.Add(this.pictureBoxImageSeason);
            this.Controls.Add(this.pictureBoxImageElement);
            this.Controls.Add(this.pictureBoxImageChineseZodiac);
            this.Controls.Add(this.labelZodiac);
            this.Controls.Add(this.labelDateToday);
            this.Controls.Add(this.pictureBoxImageZodiac);
            this.Controls.Add(this.labelTodayIs);
            this.Controls.Add(this.labelDateBirth);
            this.Controls.Add(this.buttonAnalysis);
            this.Controls.Add(this.textBoxCharacteristic);
            this.Controls.Add(this.dateBirth);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ForeColor = System.Drawing.Color.DarkOrchid;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Form1";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Гороскоп";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxImageZodiac)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxImageChineseZodiac)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxImageElement)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBoxImageSeason)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        public System.Windows.Forms.DateTimePicker dateBirth;
        private System.Windows.Forms.TextBox textBoxCharacteristic;
        private System.Windows.Forms.Button buttonAnalysis;
        private System.Windows.Forms.Label labelDateBirth;
        private System.Windows.Forms.Label labelTodayIs;
        private System.Windows.Forms.PictureBox pictureBoxImageZodiac;
        private System.Windows.Forms.Timer timerUpdate;
        private System.Windows.Forms.Label labelDateToday;
        private System.Windows.Forms.Label labelZodiac;
        private System.Windows.Forms.PictureBox pictureBoxImageChineseZodiac;
        private System.Windows.Forms.PictureBox pictureBoxImageElement;
        private System.Windows.Forms.PictureBox pictureBoxImageSeason;
        private System.Windows.Forms.Label labelChineseZodiac;
        private System.Windows.Forms.Label labelElement;
        private System.Windows.Forms.Label labelSeason;
    }
}

